/* MenuAnimationPanel.h
Copyright (c) 2022 by Michael Zahniser

Endless Sky is free software: you can redistribute it and/or modify it under the
terms of the GNU General Public License as published by the Free Software
Foundation, either version 3 of the License, or (at your option) any later version.

Endless Sky is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.  See the GNU General Public License for more details.
*/

#ifndef MENU_ANIMATION_PANEL_H_
#define MENU_ANIMATION_PANEL_H_

#include "Panel.h"



// Class representing the menu animation including sound effects and music
// that appears when the game is started and everything is loaded.
class MenuAnimationPanel final : public Panel {
public:
	MenuAnimationPanel();

	void Step() final;
	void Draw() final;


private:
	float alpha = 1.f;
};



#endif
